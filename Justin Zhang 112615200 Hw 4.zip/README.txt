Included are some pictures of my code output. The harmonic energies might not match the demo code but the output is the same reguardless.
The start up solution is in the build folder